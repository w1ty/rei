Copyright 2023 
wity shit