
var index = 1;
var tempImg = new Image ();
tempImg.onload = function () {
  appendImage ();
}
var tryLoadImage = function ( index ) {
  tempImg.src = 'imgs/rei' + index + '.png';
}
var appendImage = function () {
  var img = document.createElement ('img');
  img.src = tempImg.src;
  document.body.appendChild ( img )
  img.classList.add("form-control");
  tryLoadImage ( index++ )
}
tryLoadImage ( index );
